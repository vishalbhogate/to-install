
## Information Assets Table

| Information Asset ID | Stored | Traverses | Confidentiality | Integrity | Availability | Name | Description |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| IA-001 | N-30 | F-10;F-20 | Confidential | Standard Integrity Controls | Medium Availability | CSTRA Document |  |

## Threats Table

| Threat ID | Threat Agent | Threat Event | Vulnerability | Information Assets At Risk | Intent | Motivation | Description | Control Objectives |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| T-001 | An internal user | Accesses sensitive information | An unsecured CSTRA repository | IA-001 |  |  |  | C-48 : Identity and Access Management : Authentication |

## Logical Security Zone Model

![alt text](assets/TestDrawing1-Page-1.svg "Test Drawing 1 - Testing the Stencil")

## Nodes Table

| Node | Node Description | Status | Zone | Environment | Hosting | Data Classification | Information Assets | Control Recommendations | Comments |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| N-10 | Security Architect | Existing | User | Production Only | Australia | None |   |  |   |
| N-20 | CSTRA Web | New | Internal Controlled | Test/Dev | CBA Data Centre | None |  |  | Combined Web and App Server on ZBI |
| N-30 | Database for CSTRA | New | Restricted | Test/Dev | CBA Data Centre | Confidential | IA-001 | C-48 : Identity and Access Management : Authentication | MongoDB on ZBI |

## Flows Table

| Flow ID | Flow Description | Status | Compliant Flow | From Node Number | From Node Name | From Node Zone | From Environment | From Hosting | To Node Number | To Node Name | To Node Zone | To Environment | To Hosting | Protocols | Information Assets | Control Recommendations |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| F-10 |   | New | True | N-10 | Security Architect | User | Production Only | Australia | N-20 | CSTRA Web | Internal Controlled | Test/Dev | CBA Data Centre | HTTP | IA-001 |  |
| F-20 |   | New | True | N-20 | CSTRA Web | Internal Controlled | Test/Dev | CBA Data Centre | N-30 | Database for CSTRA | Restricted | Test/Dev | CBA Data Centre | Mongo | IA-001 |  |

## Controls Table

| Control ID | Status | Node ID | Flow ID | Control Domain | Control SubDomain | Threats | Comments |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| C-48 | Leveraged | N-30 |  | Identity and Access Management | Authentication | T-001 |  |

