exclude_rule 'MD013'
rule 'MD013', :tables => false
