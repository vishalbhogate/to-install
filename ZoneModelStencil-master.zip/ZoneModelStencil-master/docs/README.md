# ZoneModelStencil

Visio Stencil for the Logical Security Zone Model

## Installation

1. Add 'CBA_Cyber_Architecture_Cert_2024.cer' to the 'Trusted Root
   Certification Authorities' AND 'Trusted Publishers' certificate stores
   ('certmgr.msc') for the Current User
1. Copy the 'Craig_Custom_Macro.vssm' file to the 'Documents\My Shapes' folder

*Note*: Some users have noticed poor performance with Visio when connecting over
MyRAS. A solution (thanks to @bergmaan) is detailed below:

1. Create a new folder eg. c:\Users\<YourLANID>\MyShapes (NO DEEPER into the
   user profile as this folder WONT sync to the network - which is good!)
1. File/Options/Advanced/File Locations/My Shapes - Point this to the new folder

## Usage

1. Create a new blank document. HINT: Don't use a template like "Basic Diagram"
   as these generally have themes applied and this affects the look and
   behaviour.
1. Design -> Orientation -> Landscape
1. Shapes -> More Shapes -> My Shapes -> Craig_Custom_Macro
1. Drag 'Zone Map ZM5' on to the page
1. Drag 'Univeral Node ZM5' on to the page, populate Data fields, ensure a
   unique node number utilised (Recommendation: multiples of ten)
1. Drag 'Universal Flow' on to the page, ensure both ends connect (_snap_) to a
   Node. Use one flow for each direction. (Recommendation: use right snap-point
   for outbound, left snap-point for inbound). Populate Data fields.
   (Recommendation: number the flows using the origin node as the base - e.g.
   Node 10 has flows 10, 11, 12 etc)
1. Drag 'Universal Control' on to Nodes and Flows, ensuring it snaps to a Node
   or Flow. Controls can be snapped to each other in a stack. (Control naming is
   based upon the [Security Capability
   Model](https://mtspro.cba/es/CyberSecurityteam/sada/Shared%20Documents/Processes/Security%20Capability%20Model.docx))
1. Save the Document, ensure you populate 'Title' and 'Comments' fields in the
   metadata, these will populate the 'Title' and 'Description' fields
   respectively, in the Zone Map.
1. BONUS: Utilise the Excel template (Data.xltx) from this repository.
   Populate the file, and save the output to the same directory as your Visio
   file. Now ensure you've populated the Nodes and Flows with the relevant
   Information Asset identifier(s) - comma delimited. Populate Controls with the
   associated Threats. Visio will look for the file using the following names:
   1. The name of the Visio Drawing + "-" + Page Name (e.g. "LSZM-Page1.xlsx")
   1. The name of the Visio Drawing (e.g. LSZM.xlsx)
1. Right-Click a Node, and select 'Calculate ZM5 Flow Data', generated output
   will be saved in the same folder as the Visio file, named after the Visio
   file and the Visio Page.
1. Utilise the output in downstream documents - SVG (image) and MD (markdown
   text) are generated for use in ISDs, PNG (image) and CSV (Excel) files are
   generated for use in HLSAs/SSAs.
   There are currently five CSV files generated:
   1. Controls
   1. Flows
   1. Information Assets
   1. Nodes
   1. Threats

### Notes

* The Recommendations output is also written to the same directory as the Visio
    document, utilising the same Drawing-Page naming convention.

* Excel Template is 'locked' with the password 'password' to prevent inadvertent
    overwrite of key fields and lists.

### Tips

* The various items in the stencil have pre-defined Layers. A hidden layer will
    not appear on the output image, however the data from the hidden item will
    be included. For example - Control Sets have their own layer.
