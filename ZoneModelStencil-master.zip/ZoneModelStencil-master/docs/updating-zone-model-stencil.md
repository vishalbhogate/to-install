# Updating the Zone Model Stencil

## Prerequisites

- ZoneModelCert.p12 - Install this certificate into the store (right-click 'install pfx')
- Password for the above file

## Editing a Master Node Element (eg. `Universal Node`)

### Macro
- Open Visio and enable 'Developer Mode'
   - File/Options/Advanced/Developer Mode
- Close Visio
- Right-click the 'Craig_Custom_Macro.vssm' file (in Explorer) and choose `Edit`
- Save changes
- Copy the macro text (all of it) and overwrite the 'CalculateFlowData.vbs' file in the repo. This is used for documentation purposes.
- See 'Commits'

### Shapes
- In the Stencil Shapes Bar, right-click the element (eg. `Universal Node`) and choose 'Edit Master/Edit Master Shape'
- Click on the shape in the editing window to select it
- Select the 'Developer Toolbar'
- Use the options to edit for example:
   - 'Show ShapeSheet/Shape'
   - Now you can edit the details in the 'shape data'
   - Close the editing window
   - Close the shape windows
   - Save changes to the stencil when prompted
- See 'Commits'

### Commits
- Create a new branch, commit, and push, per normal repo update practices using git

